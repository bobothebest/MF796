import argparse
import numpy as np
import torch
torch.set_num_threads(1)
from os.path import isdir
import os
from core.models_lstm import LSTM
from core.functions import *
from torch.utils import data
from torch import nn, optim
from datetime import datetime
import matplotlib.pyplot as plt
from tqdm import tqdm
import pandas as pd

torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def get_data(data_input, data_label, args):
    # data_input:(N, C, T, D), data_label:(N, T, 1)
    data_loader = data.DataLoader(data.TensorDataset(data_input, data_label), batch_size=args.batch_size, shuffle=False, drop_last=False)
    return data_loader

def get_models(args):
    if args.test_checkpoint is None:
        net = LSTM(in_dim=15, in_channels=1, out_dim=1, seq_len=10)
        optimizer = optim.Adam(list(net.parameters()), amsgrad=True, lr=args.learning_rate)
    else:
        try:
            net = torch.load("/main/checkpoints/" + args.test_checkpoint + "_net", map_location=device)
            optimizer = torch.load("/main/checkpoints/" + args.test_checkpoint + "_optimizer", map_location=device)
        except FileNotFoundError:
            try:
                net = torch.load(args.test_checkpoint + "_net", map_location=device)
                optimizer = torch.load(args.test_checkpoint + "_optimizer", map_location=device)
            except:
                print("No checkpoint found at '{}'- Please specify the model for testing".format(args.test_checkpoint))
                exit()

    net.to(device)
    return net, optimizer

def train(train_loader, args):
    net, optimizer = get_models(args)
    net.train()
    criterion = nn.MSELoss()

    # make a directory to save models if it doesn't exist
    if not isdir("checkpoints"):
        os.mkdir("checkpoints")

    print("Training the model")
    loss_var = []
    for epoch in tqdm(range(args.max_epoch)):
        train_loss = []
        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad()
            y_pred = net(x)
            loss = criterion(y_pred, y)
            loss.backward()
            optimizer.step()
            train_loss.append(loss.detach().item())
        epoch_loss = np.mean(train_loss)
        loss_var.append(epoch_loss)
    plt.plot(np.arange(args.max_epoch), loss_var)
    plt.title("Training Curve")
    plt.savefig('../output/LSTM Training Curve.png')

    torch.save(net, "checkpoints/{}_net".format(args.session_name))
    torch.save(optimizer, "checkpoints/{}_optimizer".format(args.session_name))

    train_estimate_price = []
    train_true_price = []

    with torch.no_grad():
        for x, y in train_loader:
            y_hat = net(x)
            y_hat = train_label_normalization.unnormalize(y_hat)
            y = train_label_normalization.unnormalize(y)
            train_estimate_price.append(y_hat.detach().cpu().numpy().squeeze())
            train_true_price.append(y.detach().cpu().numpy())

    train_estimate_price = np.concatenate(train_estimate_price)
    train_true_price = np.concatenate(train_true_price)

    train_data = pd.read_csv(r"../data/train_data.csv")
    seq_len = 10

    # Create a dictionary to store the estimated and true prices for each optID
    estimate_price_dict = {}
    true_price_dict = {}
    index = 0

    for i in range(train_data['optID'].unique().shape[0]):
        optID = train_data['optID'].unique()[i]
        estimate_price_dict[optID] = []
        true_price_dict[optID] = []

        for _ in range(train_data.loc[(train_data['optID'] == optID)].shape[0] - seq_len + 1):
            estimate_price_dict[optID].append(train_estimate_price[index])
            true_price_dict[optID].append(train_true_price[index])
            index += 1

    # Spell the estimated and true prices back into the original train_data with 9 errors and 0 in the front
    train_data['Estimate_Price'] = np.nan
    train_data['True_Price'] = np.nan

    for optID, estimate_prices in estimate_price_dict.items():
        padded_estimate_prices = [0] * 9 + estimate_prices
        optID_rows = train_data[train_data['optID'] == optID].shape[0]
        padded_estimate_prices += [np.nan] * (optID_rows - len(padded_estimate_prices))
        train_data.loc[train_data['optID'] == optID, 'Estimate_Price'] = padded_estimate_prices

    for optID, true_prices in true_price_dict.items():
        padded_true_prices = [0] * 9 + true_prices
        optID_rows = train_data[train_data['optID'] == optID].shape[0]
        padded_true_prices += [np.nan] * (optID_rows - len(padded_true_prices))
        train_data.loc[train_data['optID'] == optID, 'True_Price'] = padded_true_prices

    # Save concatenated data to a CSV file
    train_data.to_csv("../output/LSTM train_data_with_estimate_and_true.csv", index=False)


def test(test_loader, args):
    if args.test_checkpoint is None:
        args.test_checkpoint = "checkpoints/{}".format(args.session_name)
    model, _ = get_models(args)
    criterion = nn.MSELoss()
    model.eval()

    true_price_list = []
    estimate_price_list = []

    test_loss = []
    test_map = []
    test_mape = []
    test_property_corr = []

    with torch.no_grad():
        for x, y in test_loader:
            x, y = x.to(device), y.to(device)
            y_hat = model(x)
            y = test_label_normalization.unnormalize(y)
            y_hat = test_label_normalization.unnormalize(y_hat)
            loss = criterion(y, y_hat)
            corr, map_val, mape_val = metrics(y_hat.detach(), y.detach())

            test_loss.append(loss.item())
            test_map.append(map_val.item())
            test_mape.append(mape_val.item())
            test_property_corr.append(corr.item())

            true_price_list.append(y.cpu().numpy())
            estimate_price_list.append(y_hat.cpu().numpy())

    # Concatenate all batches into single arrays
    true_price = np.concatenate(true_price_list, axis=0)
    estimate_price = np.concatenate(estimate_price_list, axis=0)

    # transit into torch and calculate mean value
    map_mean = torch.tensor(test_map).mean().item()
    mape_mean = torch.tensor(test_mape).mean().item()
    property_corr = torch.tensor(test_property_corr).mean().item()
    loss_mean = np.mean(test_loss)
    rmse = np.sqrt(loss_mean)

    print(f"MSE: {loss_mean:.5f}\nRMSE: {rmse:.5f}\nMAP: {map_mean:.5f}\nMAPE: {mape_mean:.5f}\nCorrelation: {property_corr:.5f}\n")

    # plotting
    plot_len = min(len(true_price), 120)  # Avoid going out of bounds
    plt.figure(figsize=(10, 5))
    plt.plot(range(plot_len), true_price[:plot_len], label="True Price")
    plt.plot(range(plot_len), estimate_price[:plot_len], label="Estimated Price")
    plt.legend()
    plt.xlabel('Time')
    plt.ylabel('Option Price')
    plt.title("Comparison of Estimated Price and True Price")
    plt.savefig('../output/LSTM Comparison of Estimated Price and True Price.png')

    print("Save the estimate_price and true_price of the test set to a CSV file")
    test_data = pd.read_csv(r"../data/test_data.csv", low_memory=False)
    seq_len = 10

    test_data['Estimate_Price'] = np.nan
    test_data['True_Price'] = np.nan

    index = 0
    for i in range(test_data['optID'].unique().shape[0]):
        optID = test_data['optID'].unique()[i]
        for j in range(test_data.loc[test_data['optID'] == optID].shape[0] - seq_len + 1):
            test_data.loc[(test_data['optID'] == optID) & (
                    test_data.index == test_data[test_data['optID'] == optID].index[
                j + seq_len - 1]), 'Estimate_Price'] = estimate_price[index]
            test_data.loc[(test_data['optID'] == optID) & (
                    test_data.index == test_data[test_data['optID'] == optID].index[
                j + seq_len - 1]), 'True_Price'] = true_price[index]
            index += 1

    # Save concatenated data to a CSV file
    test_data.to_csv("../output/LSTM test_data_with_estimate_and_true.csv", index=False)

if __name__ == '__main__':
    ## Arguments and parameters
    parser = argparse.ArgumentParser()
    parser.add_argument('-learning_rate', type=float, default=0.001, help="learning rate of the Adam")
    parser.add_argument('-max_epoch', type=int, default=100, help="maximum number of training epochs")
    parser.add_argument('-batch_size', type=int, default=1024, help="Batch size for training")
    parser.add_argument('-session_name', type=str, action="store", default=datetime.now().strftime('%b%d_%H%M%S'),
                        help="name of the session to be used in saving the model")
    parser.add_argument('-test_checkpoint', type=str, action="store", default=None,
                        help="path to model to test on. When this flag is used, no training is performed")
    parser.add_argument('-nonlinearity', action="store", type=str, default="tanh",
                        help="Type of nonlinearity for the CNN [tanh, relu]", choices=["tanh", "relu"])

    args = parser.parse_args()

    train_input = torch.load(r"../data/torch-data/train_input.pt").float().to(device)
    train_input_mean = torch.mean(train_input, dim=0, keepdim=True).float()
    train_input_std = torch.std(train_input, dim=0, keepdim=True).float()
    train_input_normalization = Normalization(train_input_mean, train_input_std)
    train_input = train_input_normalization.normalize(train_input)

    train_label = torch.load(r"../data/torch-data/train_label.pt").float().to(device)
    train_label_mean = torch.mean(train_label, dim=0, keepdim=False)
    train_label_std = torch.std(train_label, dim=0, keepdim=False)
    train_label_normalization = Normalization(train_label_mean, train_label_std)
    train_label = train_label_normalization.normalize(train_label)

    test_input = torch.load(r"../data/torch-data/test_input.pt").float().to(device)
    test_input_mean = torch.mean(test_input, dim=0, keepdim=True)
    test_input_std = torch.std(test_input, dim=0, keepdim=True)
    test_input_normalization = Normalization(test_input_mean, test_input_std)
    test_input = test_input_normalization.normalize(test_input)

    test_label = torch.load(r"../data/torch-data/test_label.pt").float().to(device)
    test_label_mean = torch.mean(test_label, dim=0, keepdim=False)
    test_label_std = torch.std(test_label, dim=0, keepdim=False)
    test_label_normalization = Normalization(test_label_mean, test_label_std)
    test_label = test_label_normalization.normalize(test_label)

    train_input = train_input.reshape(train_input.shape[0], 1, train_input.shape[2], train_input.shape[1] * train_input.shape[3])
    test_input = test_input.reshape(test_input.shape[0], 1, test_input.shape[2], test_input.shape[1] * test_input.shape[3])

    train_loader = get_data(train_input, train_label, args)
    test_loader = get_data(test_input, test_label, args)

    train(train_loader, args)
    test(test_loader, args)




















